from flask import render_template, request
from app import app
import urllib2
import pymongo
import json
import datetime
from filters import slugify

apikey = 'cff92ae8f5e6456211688535e0cf12c2'

c = pymongo.Connection()
db = c['moviedb']

# usage: {{ title|slug }}
@app.template_filter()
def slug(s):
  return slugify(s)

@app.route("/")
def index():
  # get config
  url_config = 'http://api.themoviedb.org/3/configuration?api_key='+apikey
  request_config = urllib2.Request(url_config, None, headers={'Accept': 'application/json'})
  response_config = urllib2.urlopen(request_config)
  config_data = json.load(response_config)

  # get box office movies
  url = 'http://api.themoviedb.org/3/movie/popular?api_key='+apikey
  request = urllib2.Request(url, None, headers={'Accept': 'application/json'})
  response = urllib2.urlopen(request)
  boxoffice_data = json.load(response)

  # join data
  # datas = dict(config_data.items() + boxoffice_data.items())
  datas = dict({'results': boxoffice_data['results']}.items() + {'base_url': config_data['images']['base_url']}.items())

  return render_template('index2.html', datas=datas)

@app.route("/watch-<movietitle>-full-movie-online-<movieid>")
def single(movietitle, movieid):
  """
  single page detail:
  if data not exists in database, load it from tmdb server, else load from database
  if data in database > 1 month, update the date from server

  sometimes, no similar movies available, so, check we check it with try except logics
  """

  # url for system wide config
  url_config = 'http://api.themoviedb.org/3/configuration?api_key='+apikey

  # url for specific movie id
  url = 'http://api.themoviedb.org/3/movie/'+movieid+'?api_key='+apikey+'&append_to_response=casts,similar_movies,reviews,upcoming,now_playing,images'
  movieid = int(movieid)

  if db.movies.find_one({'id': movieid}):  # if available in db
    data = db.movies.find_one({'id': movieid})
    
    lastupdate = data['added']  # check the timestamp
    
    today = datetime.datetime.now()
    differs = (today - lastupdate).days

    if differs > 30: # if more than a month, update it
      request = urllib2.Request(url, None, headers={'Accept': 'application/json'})
      config_request = urllib2.Request(url_config, None, headers={'Accept': 'application/json'})

      # this will avoid the non-existance similar_movies data
      try:
        response = urllib2.urlopen(request)
      except:
        url = 'http://api.themoviedb.org/3/movie/'+str(movieid)+'?api_key='+apikey+'&append_to_response=casts,reviews,upcoming,now_playing,images'
        request = urllib2.Request(url, None, headers={'Accept': 'application/json'})
        response = urllib2.urlopen(request)

      response_config = urllib2.urlopen(config_request)

      config_data = json.load(response_config)  # data config

      # change 'images' key in config_data to avoid conflict with 'images' parameter in url
      config_data['config_images'] = config_data['images']
      del config_data['images']  # del 'old' images data

      movie_data = json.load(response)  # data movies

      # join the config_data with movie_data and datetime data
      data = dict(config_data.items() + movie_data.items() + [('added', datetime.datetime.now())])

      movieid = movie_data['id']

      db.movies.update({'id': movieid}, {"$set": data})  # updating data
      
  else:
    request = urllib2.Request(url, None, headers={'Accept': 'application/json'})
    config_request = urllib2.Request(url_config, None, headers={'Accept': 'application/json'})


    # this will avoid the non-existance similar_movies data
    try:
      response = urllib2.urlopen(request)
    except:
      url = 'http://api.themoviedb.org/3/movie/'+str(movieid)+'?api_key='+apikey+'&append_to_response=casts,reviews,upcoming,now_playing,images'
      request = urllib2.Request(url, None, headers={'Accept': 'application/json'})
      response = urllib2.urlopen(request)

    response_config = urllib2.urlopen(config_request)

    config_data = json.load(response_config)  # data config

    # change 'images' key in config_data to avoid conflict with 'images' parameter in url
    config_data['config_images'] = config_data['images']
    del config_data['images']  # del 'old' images data

    movie_data = json.load(response)  # data movies

    # join the config_data with movie_data and datetime data
    data = dict(config_data.items() + movie_data.items() + [('added', datetime.datetime.now())])

    movieid = movie_data['id']

    db.movies.insert(data)  # insert data

  return render_template('single2.html', data=data)
